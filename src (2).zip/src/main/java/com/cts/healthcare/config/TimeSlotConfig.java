package com.cts.healthcare.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "app")
public class TimeSlotConfig {
    private List<TimeSlot> timeSlots;

    @Data
    public static class TimeSlot {
        private String value;
        private String display;
    }
} 