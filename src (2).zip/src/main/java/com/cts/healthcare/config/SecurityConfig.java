package com.cts.healthcare.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests((requests) -> requests
                // Public endpoints
                .requestMatchers("/", "/home", "/login", "/register", "/users/register","/users/login", "/css/**", "/js/**", "/images/**").permitAll()
                
                // Patient endpoints
                .requestMatchers("/patient/**").hasAuthority("PATIENT")
                
                // Doctor endpoints
                .requestMatchers("/doctor/**").hasAuthority("DOCTOR")
                
                // User profile endpoints
                .requestMatchers("/users/profile").authenticated()
                
                // Default to requiring authentication
                .anyRequest().authenticated()
            )
            .formLogin((form) -> form
                .loginPage("/login")
                .loginProcessingUrl("/users/login")
                .successHandler(customAuthenticationSuccessHandler())
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/users/logout")
                .logoutSuccessUrl("/home")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            )
            .csrf(csrf -> csrf.disable()) // Disable CSRF for development
            .headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable())); // Allow frames for H2 console

        return http.build();
    }

    @Bean
public AuthenticationSuccessHandler customAuthenticationSuccessHandler() {
    return (request, response, authentication) -> {
        // Get the user's role
        String role = authentication.getAuthorities().iterator().next().getAuthority();

        // Redirect based on role
        if ("PATIENT".equals(role)) {
            response.sendRedirect("/patient/dashboard");
        } else if ("DOCTOR".equals(role)) {
            response.sendRedirect("/doctor/dashboard");
        } else {
            response.sendRedirect("/home"); // Default fallback
        }
    };
}
}
