package com.cts.healthcare.repository;

import com.cts.healthcare.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // Custom query to find a user by email
    Optional<User> findByEmail(String email);
    
    // Find users by role name
    List<User> findByRole_Name(String name);
    
    // Find users by specialization
    List<User> findBySpecialization(String specialization);
}