package com.cts.healthcare.repository;

import com.cts.healthcare.entity.DoctorAvailability;
import com.cts.healthcare.entity.TimeSlot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {
    List<DoctorAvailability> findByDoctorIdAndDateAndTimeSlot(Long doctorId, LocalDate date, TimeSlot timeSlot);

    void deleteByDoctorIdAndDateAndTimeSlot(Long id, LocalDate date, TimeSlot timeSlot);
}