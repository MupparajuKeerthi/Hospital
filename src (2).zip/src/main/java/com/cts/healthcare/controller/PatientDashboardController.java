package com.cts.healthcare.controller;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.security.SecurityUtils;
import com.cts.healthcare.service.AppointmentService;
import com.cts.healthcare.service.UserService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/patient")
public class PatientDashboardController {

    private final AppointmentService appointmentService;
    private final UserService userService;
    private final SecurityUtils securityUtils;

    public PatientDashboardController(AppointmentService appointmentService, 
                                       UserService userService, 
                                       SecurityUtils securityUtils) {
        this.appointmentService = appointmentService;
        this.userService = userService;
        this.securityUtils = securityUtils;
    }

    @GetMapping("/upcoming-appointments")
    public String getUpcomingAppointments(Model model) {
        Long patientId = securityUtils.getCurrentUserId();
        if (patientId != null) {
            model.addAttribute("userId", patientId);
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            List<Appointment> upcomingAppointments = appointmentService.getUpcomingAppointments(patientId);
            model.addAttribute("appointments", upcomingAppointments);
            model.addAttribute("view", "upcoming");
            return "patient-dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/completed-appointments")
    public String getCompletedAppointments(Model model) {
        Long patientId = securityUtils.getCurrentUserId();
        if (patientId != null) {
            model.addAttribute("userId", patientId);
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            List<Appointment> completedAppointments = appointmentService.getCompletedAppointments(patientId);
            model.addAttribute("appointments", completedAppointments);
            model.addAttribute("view", "completed");
            return "patient-dashboard";
        }
        return "redirect:/login";
    }

    @PostMapping("/book-appointment")
    public String bookAppointment(@RequestParam Long doctorId,
                                   @RequestParam LocalDate date,
                                   @RequestParam String timeSlot, // Receive timeSlot as a string (snum)
                                   Model model) {
        Long patientId = securityUtils.getCurrentUserId();
        if (patientId != null) {
            User doctor = userService.getUserById(doctorId)
                    .orElseThrow(() -> new IllegalArgumentException("Doctor not found with ID: " + doctorId));
            User patient = userService.getUserById(patientId)
                    .orElseThrow(() -> new IllegalArgumentException("Patient not found with ID: " + patientId));

            // Convert the string (snum) to the TimeSlot enum
            TimeSlot selectedTimeSlot = TimeSlot.valueOf(timeSlot);

            Appointment appointment = new Appointment();
            appointment.setDoctor(doctor);
            appointment.setPatient(patient);
            appointment.setDate(date);
            appointment.setTimeSlot(selectedTimeSlot);

            String response = appointmentService.bookAppointment(appointment);
            model.addAttribute("message", response);
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            return "patient-dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/doctors-by-specialization")
    @ResponseBody
    public List<Map<String, Object>> getDoctorsBySpecialization(@RequestParam String specialization) {
        List<User> doctors = userService.getDoctorsBySpecialization(specialization);
        return doctors.stream()
                .map(doctor -> {
                    Map<String, Object> doctorMap = new HashMap<>();
                    doctorMap.put("id", doctor.getId());
                    doctorMap.put("name", doctor.getName());
                    return doctorMap;
                })
                .collect(Collectors.toList());
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        User currentUser = securityUtils.getCurrentUser();
        if (currentUser != null) {
            model.addAttribute("loggedInUser", currentUser);
            model.addAttribute("userId", currentUser.getId());
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            return "patient-dashboard";
        }
        return "redirect:/login";
    }
}