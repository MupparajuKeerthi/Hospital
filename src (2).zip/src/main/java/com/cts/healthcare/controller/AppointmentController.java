package com.cts.healthcare.controller;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.service.AppointmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;
  
    
        public AppointmentController(AppointmentService appointmentService) {
            this.appointmentService = appointmentService;
        }
        @GetMapping("/{id}")
        public ResponseEntity<Appointment> getAppointment(@PathVariable Long id) {
            Optional<Appointment> appointment = appointmentService.giveByAppointmentId(id);
        return appointment.map(ResponseEntity::ok)
                        .orElseGet(() -> ResponseEntity.notFound().build());
    }


    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@RequestBody Appointment appointment) {
        String response = appointmentService.bookAppointment(appointment);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/cancel/{id}")
    public ResponseEntity<String> cancelAppointment(@PathVariable Long id) {
        String response = appointmentService.cancelAppointment(id);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/modify/{id}")
    public ResponseEntity<String> modifyAppointment(@PathVariable Long id,
                                                     @ModelAttribute("date") LocalDate newDate,
                                                     @ModelAttribute("timeSlot") TimeSlot newTimeSlot) {
        String response = appointmentService.modifyAppointment(id, newDate, newTimeSlot);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/complete/{id}")
    public ResponseEntity<String> completeAppointment(@PathVariable Long id) {
        String response = appointmentService.completeAppointment(id);
        return ResponseEntity.ok(response);
    }
}