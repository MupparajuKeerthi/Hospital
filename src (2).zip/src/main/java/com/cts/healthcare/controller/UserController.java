package com.cts.healthcare.controller;

import com.cts.healthcare.entity.Role;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.security.SecurityUtils;
import com.cts.healthcare.service.UserService;
import com.cts.healthcare.repository.RoleRepository;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    private final SecurityUtils securityUtils;
    private final RoleRepository roleRepository;
    public final PasswordEncoder passwordEncoder;

    public UserController(UserService userService, SecurityUtils securityUtils, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {   
        this.userService = userService;
        this.securityUtils = securityUtils;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public String login(@ModelAttribute User user, HttpServletRequest request, Model model) {
        Optional<User> existingUser = userService.getUserByEmail(user.getEmail());
        if (existingUser.isPresent() && existingUser.get().getPassword().equals(user.getPassword())) {
            // Store user ID in session
            request.getSession().setAttribute("userId", existingUser.get().getId());
    
            // Check the user's role
            String roleName = existingUser.get().getRole().getName();
            if (Role.ROLE_PATIENT.equals(roleName)) {
                return "redirect:/patient/dashboard"; // Redirect to Patient Dashboard
            } else if (Role.ROLE_DOCTOR.equals(roleName)) {
                return "redirect:/doctor/dashboard"; // Redirect to Doctor Dashboard
            } else {
                model.addAttribute("error", "Access denied for this role.");
                return "login"; // Return to login page with error message
            }
        } else {
            model.addAttribute("error", "Invalid email or password.");
            return "login"; // Return to login page with error message
        }
    }

    @GetMapping("/profile")
    public String getUserProfile(Model model) {
        User currentUser = securityUtils.getCurrentUser();
        if (currentUser != null) {
            model.addAttribute("user", currentUser);
            return "user-profile";
        }
        return "redirect:/home";
    }

    @PostMapping("/profile")
    public String updateUserProfile(@ModelAttribute User updatedUser, Model model) {
        User currentUser = securityUtils.getCurrentUser();
        if (currentUser != null) {
            // Update the fields based on the form submission
            currentUser.setName(updatedUser.getName());
            currentUser.setEmail(updatedUser.getEmail());
            currentUser.setPhoneNo(updatedUser.getPhoneNo());

            // Only update the password if a new one is provided
            if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
                currentUser.setPassword(updatedUser.getPassword());
            }

            userService.saveUser(currentUser);
            model.addAttribute("success", "Profile updated successfully!");
            model.addAttribute("user", currentUser);
            return "user-profile";
        }
        return "redirect:/home";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
    try {
        if (userService.getUserByEmail(user.getEmail()).isPresent()) {
            model.addAttribute("error", "Email is already registered.");
            return "register";
        }

        // Get the role from the database
        String roleName = user.getRole().getName();
        Optional<Role> existingRole = roleRepository.findByName(roleName);

        if (existingRole.isEmpty()) {
            model.addAttribute("error", "Invalid role selected.");
            return "register";
        }

        // Set the existing role to the user
        user.setRole(existingRole.get());

        // Set specialization to null for patients
        if (Role.ROLE_PATIENT.equals(roleName)) {
            user.setSpecialization(null);
        }

        // Encrypt the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Save the user
        userService.saveUser(user);
        model.addAttribute("success", "Registration successful!");
        return "login";
    } catch (Exception e) {
        model.addAttribute("error", "Registration failed: " + e.getMessage());
        return "register";
    }
}
}
