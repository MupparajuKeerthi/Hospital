package com.cts.healthcare.controller;

import com.cts.healthcare.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
    @GetMapping({"/","/home"})
    public String showHomePage() {
        return "home"; // Returning the name of the Thymeleaf template
    }
    @GetMapping("/register")
    public String showRegisterPage(Model model) {
        model.addAttribute("user", new User()); // Adding a new User object to the model
        return "register"; // Returning the name of the Thymeleaf template
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // Returning the name of the Thymeleaf template
    }
}
