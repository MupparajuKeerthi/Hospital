package com.cts.healthcare.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class DoctorAvailability {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "availability_seq")
    @SequenceGenerator(name = "availability_seq", sequenceName = "availability_sequence", allocationSize = 1)
    private Long availabilityId;

    @ManyToOne
    @JoinColumn(name = "doctorId")
    private User doctor;
    @Column(name="app_date")
    private LocalDate date;

    @Enumerated(EnumType.STRING)
    private TimeSlot timeSlot;
}
