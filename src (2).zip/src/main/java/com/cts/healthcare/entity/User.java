package com.cts.healthcare.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq")
    @SequenceGenerator(name = "user_seq", sequenceName = "user_sequence", allocationSize = 1)
    @Column(name = "user_id")
    private Long Id;

    private String name;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

    private String specialization;

    @Column(unique = true)
    private String phoneNo;

    @Column(unique = true)
    private String email;

    private String password;

    // Add this method to handle role binding from the form
    public void setRoleName(String roleName) {
        if (this.role == null) {
            this.role = new Role();
        }
        this.role.setName(roleName);
    }

    // Add this method to get the role name for the form
    public String getRoleName() {
        return this.role != null ? this.role.getName() : null;
    }
}


