package com.cts.healthcare.security;

import com.cts.healthcare.entity.User;
import com.cts.healthcare.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class SecurityUtils {

    private final UserService userService;

    public SecurityUtils(UserService userService) {
        this.userService = userService;
    }

    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            String email = authentication.getName();
            return userService.getUserByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found"));
        }
        return null;
    }

    public Long getCurrentUserId() {
        User user = getCurrentUser();
        return user != null ? user.getId() : null;
    }

    public boolean isCurrentUserPatient() {
        User user = getCurrentUser();
        return user != null && "PATIENT".equals(user.getRole().getName());
    }

    public boolean isCurrentUserDoctor() {
        User user = getCurrentUser();
        return user != null && "DOCTOR".equals(user.getRole().getName());
    }
} 