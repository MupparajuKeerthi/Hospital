package com.cts.healthcare.service;

import com.cts.healthcare.entity.DoctorAvailability;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.repository.DoctorAvailabilityRepository;
import org.springframework.stereotype.Service;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.UserRepository;
import java.time.LocalDate;
import java.util.*;

@Service
public class DoctorAvailabilityService {

    private final DoctorAvailabilityRepository availabilityRepository;
    private final UserRepository userRepository;
    public DoctorAvailabilityService(DoctorAvailabilityRepository availabilityRepository, UserRepository userRepository) {
        this.availabilityRepository = availabilityRepository;
        this.userRepository = userRepository;
    }
    

    public List<DoctorAvailability> getAvailabilityByDoctor(Long doctorId) {
        return availabilityRepository.findByDoctorIdAndDateAndTimeSlot(doctorId, null, null);
    }

    public boolean bookAppointment(Long doctorId, LocalDate date, TimeSlot timeSlot) {
        // Check if the time slot is already in the availability table
        Optional<DoctorAvailability> availability = availabilityRepository.findByDoctorIdAndDateAndTimeSlot(
                doctorId, date, timeSlot
        ).stream().findFirst();
    
        if (availability.isEmpty()) {
            // If not present, add it to the availability table and book the appointment
            DoctorAvailability newAvailability = new DoctorAvailability();
        
            User doctor = userRepository.findById(doctorId)
                    .orElseThrow(() -> new IllegalArgumentException("Doctor not found with ID: " + doctorId));
            
            newAvailability.setDoctor(doctor); // Set the existing doctor
            newAvailability.setDate(date);
            newAvailability.setTimeSlot(timeSlot);
            availabilityRepository.save(newAvailability);
            return true;
        }
        // If present, return false (time slot is already booked or unavailable)
        return false;
    }
    public void cancelAppointment(Long doctorId, LocalDate date, TimeSlot timeSlot) {
        // Remove the time slot from the availability table
        Optional<DoctorAvailability> availability = availabilityRepository.findByDoctorIdAndDateAndTimeSlot(
                doctorId, date, timeSlot
        ).stream().findFirst();

        availability.ifPresent(availabilityRepository::delete);
    }
}