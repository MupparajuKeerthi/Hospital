package com.cts.healthcare.entity;


public enum Status {
    BOOKED, COMPLETED, CANCELLED
}
