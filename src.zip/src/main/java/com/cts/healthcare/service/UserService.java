package com.cts.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }
    

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    public Optional<User> getUserByRole(String role) {
        return userRepository.findByRole(role);
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }
    // Example in UserService
    public List<User> getDoctorsBySpecialization(String specialization) {
        // Implement logic to fetch doctors based on specialization
        return userRepository.findBySpecialization(specialization);
    }
    public Optional<User> getLoggedInUser() {
        return Optional.ofNullable(userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()))
            .orElseThrow(() -> new IllegalArgumentException("User not found with email: " + SecurityContextHolder.getContext().getAuthentication().getName()));
    }
    
}
