package com.cts.healthcare.controller;

import com.cts.healthcare.entity.User;
import com.cts.healthcare.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public String login(@ModelAttribute User user, HttpServletRequest request, Model model) {
        Optional<User> existingUser = userService.getUserByEmail(user.getEmail());
        if (existingUser.isPresent() && existingUser.get().getPassword().equals(user.getPassword())) {
            // Store user ID in session
            request.getSession().setAttribute("userId", existingUser.get().getId());
    
            // Check the user's role
            switch (existingUser.get().getRole()) {
                case PATIENT:
                    return "redirect:/patient/dashboard"; // Redirect to Patient Dashboard
                case DOCTOR:
                    return "redirect:/doctor/dashboard"; // Redirect to Doctor Dashboard
                default:
                    model.addAttribute("error", "Access denied for this role.");
                    return "login"; // Return to login page with error message
            }
        } else {
            model.addAttribute("error", "Invalid email or password.");
            return "login"; // Return to login page with error message
        }
    }
        @GetMapping("/logout")
        public String logout(HttpServletRequest request) {
            request.getSession().invalidate(); // Invalidate the session
            return "redirect:/home"; // Redirect to login page
        }
    
        @GetMapping("/profile")
        public String getUserProfile(HttpServletRequest request, Model model) {
            Long userId = (Long) request.getSession().getAttribute("userId");
            if (userId != null) {
                Optional<User> user = userService.getUserById(userId);
                if (user.isPresent()) {
                    model.addAttribute("user", user.get());
                    return "user-profile"; // Return to user profile page
                }
            }
            return "redirect:/home"; // Redirect to login page if user ID not found in session
        }
        @PostMapping("/profile")
        public String updateUserProfile(@ModelAttribute User updatedUser, HttpServletRequest request, Model model) {
            Long userId = (Long) request.getSession().getAttribute("userId");
            if (userId != null) {
                Optional<User> existingUserOptional = userService.getUserById(userId);
                if (existingUserOptional.isPresent()) {
                    User existingUser = existingUserOptional.get();

                    // Update the fields based on the form submission
                    existingUser.setName(updatedUser.getName());
                    existingUser.setEmail(updatedUser.getEmail());
                    existingUser.setPhoneNo(updatedUser.getPhoneNo()); // Use phoneNo to match HTML

                    // Only update the password if a new one is provided (and handle encoding!)
                    if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
                        // **IMPORTANT: Encode the new password before saving!**
                        existingUser.setPassword(updatedUser.getPassword());
                    }

                    userService.saveUser(existingUser);
                    model.addAttribute("success", "Profile updated successfully!");
                    model.addAttribute("user", existingUser); // Re-add the updated user to the model
                    return "user-profile";
                } else {
                    // Handle the case where the user ID in the session is invalid
                    return "redirect:/home?error=invalidUserId";
                }
            } else {
                // Handle the case where there's no user ID in the session (user not logged in)
                return "redirect:/home";
            }
        }   

        @PostMapping("/register")
        public String register(@ModelAttribute User user, Model model) {
            if (userService.getUserByEmail(user.getEmail()).isPresent()) {
                model.addAttribute("error", "Email is already registered.");
                return "register"; // Return to register page with error message
            }
            if (user.getRole() != null && user.getRole().toString().equalsIgnoreCase("PATIENT")) {
                user.setSpecialization(null);
            }
            userService.saveUser(user);
            model.addAttribute("success", "Registration successful!");
            return "login"; // Return to register page with success message
        }
        


}
