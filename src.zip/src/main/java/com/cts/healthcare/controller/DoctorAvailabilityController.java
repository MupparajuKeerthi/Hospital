package com.cts.healthcare.controller;

import com.cts.healthcare.entity.DoctorAvailability;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.service.DoctorAvailabilityService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/availability")
public class DoctorAvailabilityController {

    private final DoctorAvailabilityService availabilityService;

    public DoctorAvailabilityController(DoctorAvailabilityService availabilityService) {
        this.availabilityService = availabilityService;
    }

    @GetMapping("/{doctorId}")
    public ResponseEntity<List<DoctorAvailability>> getAvailabilityByDoctor(@PathVariable Long doctorId) {
        List<DoctorAvailability> availability = availabilityService.getAvailabilityByDoctor(doctorId);
        return ResponseEntity.ok(availability);
    }

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@RequestParam Long doctorId,
                                                   @RequestParam LocalDate date,
                                                   @RequestParam TimeSlot timeSlot) {
        boolean success = availabilityService.bookAppointment(doctorId, date, timeSlot);
        if (success) {
            return ResponseEntity.ok("Appointment booked successfully!");
        } else {
            return ResponseEntity.status(400).body("Time slot is already booked or unavailable!");
        }
    }

    @PostMapping("/cancel")
    public ResponseEntity<String> cancelAppointment(@RequestParam Long doctorId,
                                                     @RequestParam LocalDate date,
                                                     @RequestParam TimeSlot timeSlot) {
        availabilityService.cancelAppointment(doctorId, date, timeSlot);
        return ResponseEntity.ok("Appointment canceled and time slot marked as available!");
    }
}