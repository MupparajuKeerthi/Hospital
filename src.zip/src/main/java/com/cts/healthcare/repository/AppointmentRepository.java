package com.cts.healthcare.repository;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.TimeSlot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.cts.healthcare.entity.Status;
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    Optional<Appointment> findByAppointmentId(Long appointmentId);
    List<Appointment> findByDoctorIdAndDateAndTimeSlot(Long doctorId, LocalDate date, TimeSlot timeSlot);
    List<Appointment> findByPatientIdAndStatus(Long patientId, Status status);
}