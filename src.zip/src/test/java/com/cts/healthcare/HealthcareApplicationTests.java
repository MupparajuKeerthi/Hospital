package com.cts.healthcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareApplicationTests {

	@Test
	void contextLoads() {
	}

}
