package com.example.healthcare.repository;

import com.example.healthcare.entity.Appointment;
import com.example.healthcare.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByPatient(User patient);
    List<Appointment> findByDoctor(User doctor);
    List<Appointment> findByDoctorAndAppointmentDateTimeBetween(User doctor, LocalDateTime start, LocalDateTime end);
    List<Appointment> findByDoctorAndStatus(User doctor, Appointment.AppointmentStatus status);
    List<Appointment> findByPatientAndStatus(User patient, Appointment.AppointmentStatus status);
    boolean existsByDoctorAndAppointmentDateTime(User doctor, LocalDateTime appointmentDateTime);
    
    List<Appointment> findByPatientId(Long patientId);
    
    List<Appointment> findByDoctorId(Long doctorId);
    
    List<Appointment> findByDoctorIdAndAppointmentDateTimeBetween(
        Long doctorId, 
        LocalDateTime startDateTime, 
        LocalDateTime endDateTime
    );
} 