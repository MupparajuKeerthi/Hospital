package com.example.healthcare.service;

import com.example.healthcare.entity.Appointment;
import com.example.healthcare.entity.User;
import com.example.healthcare.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private UserService userService;

    public Appointment bookAppointment(Appointment appointment) {
        // Validate appointment time
        if (appointment.getAppointmentDateTime().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Cannot book appointment in the past");
        }

        // Check if slot is already booked
        if (appointmentRepository.existsByDoctorAndAppointmentDateTime(
                appointment.getDoctor(), appointment.getAppointmentDateTime())) {
            throw new RuntimeException("This time slot is already booked");
        }

        // Set status to SCHEDULED
        appointment.setStatus(Appointment.AppointmentStatus.SCHEDULED);
        return appointmentRepository.save(appointment);
    }

    public void cancelAppointment(Long appointmentId, User user) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        // Check if user has permission to cancel
        if (!appointment.getPatient().equals(user) && !appointment.getDoctor().equals(user)) {
            throw new RuntimeException("You don't have permission to cancel this appointment");
        }

        appointment.setStatus(Appointment.AppointmentStatus.CANCELLED);
        appointmentRepository.save(appointment);
    }

    public List<Appointment> getPatientAppointments(Long patientId) {
        User patient = userService.getUserById(patientId);
        return appointmentRepository.findByPatient(patient);
    }

    public List<Appointment> getDoctorAppointments(Long doctorId) {
        User doctor = userService.getUserById(doctorId);
        return appointmentRepository.findByDoctor(doctor);
    }

    public List<LocalDateTime> getAvailableTimeSlots(Long doctorId, LocalDateTime date) {
        User doctor = userService.getUserById(doctorId);
        LocalDateTime startOfDay = date.with(LocalTime.MIN);
        LocalDateTime endOfDay = date.with(LocalTime.MAX);

        // Get all appointments for the day
        List<Appointment> existingAppointments = appointmentRepository
                .findByDoctorAndAppointmentDateTimeBetween(doctor, startOfDay, endOfDay);

        // Generate available slots (assuming 1-hour slots from 9 AM to 5 PM)
        List<LocalDateTime> allSlots = generateTimeSlots(date);
        
        // Remove booked slots
        existingAppointments.forEach(appointment -> 
            allSlots.remove(appointment.getAppointmentDateTime()));

        return allSlots;
    }

    private List<LocalDateTime> generateTimeSlots(LocalDateTime date) {
        // Generate slots from 9 AM to 5 PM
        LocalDateTime start = date.with(LocalTime.of(9, 0));
        LocalDateTime end = date.with(LocalTime.of(17, 0));
        
        List<LocalDateTime> slots = new ArrayList<>();
        LocalDateTime current = start;
        
        while (!current.isAfter(end)) {
            slots.add(current);
            current = current.plusHours(1);
        }
        
        return slots;
    }

    public Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
    }
} 