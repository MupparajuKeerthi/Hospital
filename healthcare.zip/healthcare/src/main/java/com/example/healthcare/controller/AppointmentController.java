package com.example.healthcare.controller;

import com.example.healthcare.entity.Appointment;
import com.example.healthcare.entity.User;
import com.example.healthcare.service.AppointmentService;
import com.example.healthcare.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private UserService userService;

    @GetMapping("/book/{doctorId}")
    public String showBookingForm(@PathVariable Long doctorId, Model model) {
        User doctor = userService.getUserById(doctorId);
        if (doctor == null || !doctor.getRole().name().equals("DOCTOR")) {
            return "redirect:/error";
        }

        model.addAttribute("doctor", doctor);
        model.addAttribute("appointment", new Appointment());
        return "book-appointment";
    }

    @PostMapping("/book")
    public String bookAppointment(@RequestParam Long doctorId,
                                @RequestParam String date,
                                @RequestParam String time,
                                @RequestParam(required = false) String reason,
                                Model model) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            User patient = userService.getUserByUsername(username);
            User doctor = userService.getUserById(doctorId);

            // Parse date and time
            LocalDateTime appointmentDateTime = LocalDateTime.parse(date + "T" + time);

            // Create new appointment
            Appointment appointment = new Appointment();
            appointment.setPatient(patient);
            appointment.setDoctor(doctor);
            appointment.setAppointmentDateTime(appointmentDateTime);
            appointment.setStatus(Appointment.AppointmentStatus.SCHEDULED);
            appointment.setReason(reason);

            // Save appointment
            Appointment savedAppointment = appointmentService.bookAppointment(appointment);
            return "redirect:/appointments/success/" + savedAppointment.getId();
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "redirect:/user/dashboard";
        }
    }

    @GetMapping("/available-slots/{doctorId}")
    @ResponseBody
    public List<String> getAvailableTimeSlots(@PathVariable Long doctorId, 
                                            @RequestParam String date) {
        LocalDateTime selectedDate = LocalDateTime.parse(date + "T00:00:00");
        List<LocalDateTime> slots = appointmentService.getAvailableTimeSlots(doctorId, selectedDate);
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        return slots.stream()
                .map(slot -> slot.format(formatter))
                .collect(java.util.stream.Collectors.toList());
    }

    @GetMapping("/success/{appointmentId}")
    public String showSuccessPage(@PathVariable Long appointmentId, Model model) {
        Appointment appointment = appointmentService.getAppointmentById(appointmentId);
        model.addAttribute("appointment", appointment);
        return "appointment-success";
    }

    @GetMapping("/my-appointments")
    public String showMyAppointments(Model model) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            User user = userService.getUserByUsername(username);
            System.out.println("Fetching appointments for user: " + username);

            List<Appointment> appointments;
            if (user.getRole().name().equals("PATIENT")) {
                appointments = appointmentService.getPatientAppointments(user.getId());
            } else {
                appointments = appointmentService.getDoctorAppointments(user.getId());
            }
            System.out.println("Found " + appointments.size() + " appointments");

            model.addAttribute("appointments", appointments);
            model.addAttribute("user", user);
            return "my-appointments";
        } catch (Exception e) {
            System.out.println("Error fetching appointments: " + e.getMessage());
            model.addAttribute("error", "Error fetching appointments: " + e.getMessage());
            return "redirect:/user/dashboard";
        }
    }

    @PostMapping("/cancel/{appointmentId}")
    public String cancelAppointment(@PathVariable Long appointmentId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);

        appointmentService.cancelAppointment(appointmentId, user);
        return "redirect:/appointments/my-appointments";
    }
} 