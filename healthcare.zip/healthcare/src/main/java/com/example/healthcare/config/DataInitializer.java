package com.example.healthcare.config;

import com.example.healthcare.entity.User;
import com.example.healthcare.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initData(UserRepository userRepository) {
        return args -> {
            // Create an admin user
            if (!userRepository.existsByUsername("admin")) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin"));
                admin.setEmail("admin@healthcare.com");
                admin.setFullName("Admin User");
                admin.setRole(User.UserRole.ADMIN);
                admin.setPhoneNumber("1234567890");
                userRepository.save(admin);
            }

            // Create sample doctors with different specializations
            String[] specializations = {"CARDIOLOGY", "DERMATOLOGY", "ENDOCRINOLOGY", "GASTROENTEROLOGY", 
                                     "NEUROLOGY", "ONCOLOGY", "ORTHOPEDICS", "PEDIATRICS", 
                                     "PSYCHIATRY", "RADIOLOGY"};

            for (int i = 0; i < specializations.length; i++) {
                String username = "doctor" + (i + 1);
                if (!userRepository.existsByUsername(username)) {
                    User doctor = new User();
                    doctor.setUsername(username);
                    doctor.setPassword(passwordEncoder.encode("doctor" + (i + 1)));
                    doctor.setEmail("doctor" + (i + 1) + "@healthcare.com");
                    doctor.setFullName("Dr. " + specializations[i] + " Specialist");
                    doctor.setRole(User.UserRole.DOCTOR);
                    doctor.setSpecialization(specializations[i]);
                    doctor.setPhoneNumber("98765432" + (i + 10));
                    userRepository.save(doctor);
                }
            }

            // Create a sample patient
            if (!userRepository.existsByUsername("patient")) {
                User patient = new User();
                patient.setUsername("patient");
                patient.setPassword(passwordEncoder.encode("patient"));
                patient.setEmail("patient@healthcare.com");
                patient.setFullName("Jane Doe");
                patient.setRole(User.UserRole.PATIENT);
                patient.setPhoneNumber("5555555555");
                userRepository.save(patient);
            }
        };
    }
} 