package com.example.healthcare.controller;

import com.example.healthcare.entity.User;
import com.example.healthcare.service.UserService;
import com.example.healthcare.entity.Appointment;
import com.example.healthcare.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        if (!model.containsAttribute("user")) {
            model.addAttribute("user", new User());
        }
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, RedirectAttributes redirectAttributes) {
        try {
            // Validate required fields
            if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                throw new RuntimeException("Username is required");
            }
            if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                throw new RuntimeException("Password is required");
            }
            if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
                throw new RuntimeException("Email is required");
            }
            if (user.getFullName() == null || user.getFullName().trim().isEmpty()) {
                throw new RuntimeException("Full name is required");
            }
            if (user.getRole() == null) {
                throw new RuntimeException("Role is required");
            }

            // Validate specialization for doctors
            if (user.getRole().name().equals("DOCTOR") && (user.getSpecialization() == null || user.getSpecialization().trim().isEmpty())) {
                throw new RuntimeException("Specialization is required for doctors");
            }

            // Clear specialization for non-doctors
            if (!user.getRole().name().equals("DOCTOR")) {
                user.setSpecialization(null);
            }

            userService.registerUser(user);
            redirectAttributes.addFlashAttribute("message", "Registration successful! Please login.");
            return "redirect:/login";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            redirectAttributes.addFlashAttribute("user", user);
            return "redirect:/user/register";
        }
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        String username = authentication.getName();
        User user = userService.getUserByUsername(username);
        
        model.addAttribute("user", user);
        
        if (user.getRole().name().equals("PATIENT")) {
            // Add appointments for patient
            List<Appointment> appointments = appointmentService.getPatientAppointments(user.getId());
            model.addAttribute("appointments", appointments);
            return "patient/dashboard";
        } else if (user.getRole().name().equals("DOCTOR")) {
            // Add appointments for doctor
            List<Appointment> appointments = appointmentService.getDoctorAppointments(user.getId());
            model.addAttribute("appointments", appointments);
            return "doctor/dashboard";
        } else {
            return "admin/dashboard";
        }
    }

    @GetMapping("/doctors")
    public String showDoctors(Model model) {
        model.addAttribute("doctors", userService.getAllDoctors());
        return "doctors";
    }

    @GetMapping("/doctors/{specialization}")
    @ResponseBody
    public List<User> getDoctorsBySpecialization(@PathVariable String specialization) {
        System.out.println("Fetching doctors for specialization: " + specialization);
        List<User> doctors = userService.getDoctorsBySpecialization(specialization);
        System.out.println("Found doctors: " + doctors.size());
        return doctors;
    }
} 